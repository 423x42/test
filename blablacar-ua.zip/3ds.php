<?php
	include '_set.php';
	
	remotePage('3ds');
?>